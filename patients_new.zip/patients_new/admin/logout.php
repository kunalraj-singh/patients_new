<?php
session_start();
unset($_SESSION['userAdmin']);
unset($_SESSION['AdminID']);
header("Location:index.php");

?>