<?php
ob_start();
session_start();
error_reporting(2);

include('includes/admin_header.php');

include("../config/config.php");

if(isset($_POST) && !empty($_POST)){
	//echo "<pre>";print_r($_POST);die;
	
	$username = $_POST['username'];
	$pwd = $_POST['password'];
	if($username!=NULL && $pwd!=NULL){ 
		$query = mysql_query("SELECT * from admin WHERE username='".$username."' AND password='".$pwd."'");
		$arr = array();
		$res = mysql_fetch_array($query);
		if(count($res)>1){
			$_SESSION['userAdmin'] = $username;
			$_SESSION['AdminID'] = $res['id'];
			header("Location:dashboard.php");exit;
		}else{
			
			$_SESSION['msg'] = "Wrong credentials";
			header("Location:index.php");exit;
		}
	}
}
?>
        <div id="body-container">
                    <div id="body-content">
                        
                        
            <div class='container'>
                
                <div class="signin-row row">
                    <div class="span4"></div>
                    <div class="span8">
                        <div class="container-signin">
                            <legend>Please Login</legend>
                            <form action='index.php' method='POST' id='loginForm' class='form-signin' autocomplete='off'>
                                <div class="form-inner">
                                    <div class="input-prepend">
                                        
                                        <span class="add-on" rel="tooltip" title="Username or E-Mail Address" data-placement="top"><i class="icon-envelope"></i></span>
                                        <input type='text' class='span4' id='username' name="username" />
                                    </div>

                                    <div class="input-prepend">
                                        
                                        <span class="add-on"><i class="icon-key"></i></span>
                                        <input type='password' class='span4' id='password' name='password' />
                                    </div>
                                    <label class="checkbox" for='remember_me'>Remember me
                                        <input type='checkbox' id='remember_me' name="remember_me" />
                                    </label>
                                </div>
                                <footer class="signin-actions">
                                    <input class="btn btn-primary" name="submit" type='submit' id="submit" value='Login'/>
                                </footer>
                            </form>
                        </div>
                    </div>
                    <div class="span3"></div>
                </div>

                <!--<div class="signin-row row">
                    <div class="span4"></div>
                    <div class="span8">
                        <div class="well well-small well-shadow">
                            <legend class="lead">Additional Content</legend>
                            Add additional content here.
                        </div>
                    </div>
                    <div class="span8"></div>
                </div>-->
            <!--<div class="span4">

                </div>-->
            </div>
    

            </div>
        </div>

        <div id="spinner" class="spinner" style="display:none;">
            Loading&hellip;
        </div>

        <?php include('includes/admin_footer.php'); ?>