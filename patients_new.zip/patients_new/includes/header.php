<?php
include('./config/config.php');
include('./classFile/Patient.php');
include('./classFile/Doctor.php');
include('./classFile/MyClass.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Home</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery/jquery-1.8.2.min.js"> </script>
<style type="text/css">
.error {
	color:#ff0000;
	background-color:#f9d0f2;
	border:solid 1px #ff0000;
	min-height:15px;
	padding:2px 5px 3px 5px;
	width:342px;
	font: 12px Arial, Helvetica, sans-serif;
}
.top-error {
	color:#ff0000;
	background-color:#f9d0f2;
	border:solid 1px #ff0000;
	min-height:20px;
	padding:5px 5px 5px 5px;
	width:620px;
	font: 12px Arial, Helvetica, sans-serif;
}
.success {
	color:#104403f2;
	background-color:#33ff009e;
	border:solid 1px #104403f2;
	min-height:20px;
	padding:5px 5px 5px 5px;
	width:620px;
	font: 12px Arial, Helvetica, sans-serif;
}
.frm_head{
	font: normal 16px Tahoma, Helvetica, sans-serif;
    color: #9db221;
	margin: 5px 0px 10px 9px;
}
</style>
</head>
<body>
<div class="main">
  <div class="main-wappper-div">
	<div class="header">
      <div class="head_2">
        <div class="block_header">
          <div class="logo"><a href="index.html"><img src="images/logo.jpg" alt="Home" width="412" height="116" border="0" /></a></div>
          <div class="search-top">
            <table width="225" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="10" align="left" valign="top"><img src="images/search-left-img.jpg" width="10" height="29" /></td>
                <td align="left" valign="middle" style="background:url(images/search-centear-img.jpg) repeat-x;"><input name="Search" type="text"  class="top-search-air" id="Search" value="Search"/></td>
                <td width="10" align="left" valign="top"><img src="images/search-right-img.jpg" width="10" height="29" /></td>
                <td width="10" align="left" valign="top">&nbsp;</td>
                <td width="29" align="left" valign="top"><img src="images/top-search-icon.jpg" width="29" height="29" /></td>
              </tr>
            </table>
          </div>
          <div class="clr"></div>
        </div>
        <div class="menu">
          <ul>
            <li><a href="#" class="active">Home</a></li>
            <li><a href="#">About us</a></li>
            <li><a href="#">Openness</a></li>
            <!--<li><a href="#">Register</a></li>
            <li><a href="#">Press</a></li>
            <li><a href="#">Careers</a></li>
            <li><a href="#">Privacy</a></li>
            <li><a href="#">FAQ</a></li>-->
            <li><a href="#">User Agreement</a></li>
            <li style="background:none;"><a href="#">Contact Us</a></li>
          </ul>
        </div>
        <div class="clr"></div>
        <div class="bennar"><img src="images/bennar.jpg" width="1014" height="237" /></div>
      </div>
    </div>