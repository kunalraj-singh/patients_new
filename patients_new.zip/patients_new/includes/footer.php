<div class="footer">
      <div class="footer-details">
        <div class="footer-details-out">
          <div class="footer-social-icon">
            <div class="footer-social-icon-img"><img src="images/facebook-img.jpg" width="232" height="45" /></div>
            <div class="footer-social-icon-img"><img src="images/linkedin-img.jpg" width="232" height="45" /></div>
            <div class="footer-social-icon-img"><img src="images/photostream-img.jpg" width="232" height="45" /></div>
            <div class="footer-social-icon-img"><img src="images/twitter-img.jpg" width="232" height="45" /></div>
          </div>
          <div class="footer-main-menu">
            <div class="footer-menu-heading">Main Menu</div>
            <div class="footer-link" style="width:135px; float:left">Home<br />
              About Us<br />
              Openness<br />
              Blog<br />
              Press</div>
            <div class="footer-link" style="width:135px; float:left">Careers<br />
              Privacy<br />
              User Agreement<br />
              Contact Us</div>
          </div>
          <div class="footer-reach-us">
            <div class="footer-menu-heading">Main Menu</div>
            <div class="reach-us-details">Patients Like me <br />
              3, Lorem Ipsum is simply dummy, <br />
              OPP. Lorem Ipsum is simply dummy text of the printing<br />
              Phone-079-2744458, MOBILE: 8511400567 </div>
            <div class="reach-us-details"> 3, Lorem Ipsum is simply dummy, <br />
              OPP. Lorem Ipsum is simply dummy text of the printing<br />
              Phone-079-2744458, MOBILE: 8511400567 </div>
          </div>
          <div class="clr"></div>
        </div>
      </div>
      <div class="copy-right">Copyright © 2012, Patientslikeme.com. All Rights Reserved</div>
    </div>
    
    </div>
  </div>
</body>
</html>