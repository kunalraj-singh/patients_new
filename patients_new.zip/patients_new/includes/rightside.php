<div class="right">
        <div class="body-row">
          <h3><span>Login</span> Form</h3>
          <input name="" type="text" class="login-search" style="width:230px" />
          <input name="" type="password" class="login-search" style="width:230px" />
          <div style="margin-bottom:8px;">
            <input name="" type="checkbox" value="" />
            &nbsp;<span class="body-details">Remember Me </span></div>
          <div style="margin-bottom:8px;" class="body-green-details"><a href="#">Forgot password?</a></div>
          <div><img src="images/login-buttan.jpg" width="60" height="30" style="margin-right:12px;" /><a href="register.php"><img src="images/signup-buttan.jpg" width="70" height="30" /></a></div>
        </div>
        <div class="body-row">
          <h3><span>Our</span> Services</h3>
          <div class="body-right-list">
            <ul>
              <li><img src="images/our-services.jpg" width="19" height="18" /><span>Find Patients like you</span></li>
              <li><img src="images/our-services2.jpg" width="19" height="18" /><span>Explore our Treatment reports</span></li>
              <li><img src="images/our-services3.jpg" width="19" height="18" /><span>Learn about Symptoms</span></li>
              <li><img src="images/our-services4.jpg" width="19" height="18" /><span>Check for your Conditions</span></li>
              <li><img src="images/our-services5.jpg" width="19" height="18" /><span>Read about the company</span></li>
              <li><img src="images/our-services6.jpg" width="19" height="18" /><span>How we make money</span></li>
            </ul>
          </div>
        </div>
        <div class="body-row" style="margin-bottom:0px;"> <img src="images/join-free-img.jpg" width="234" height="247" /></div>
      </div>