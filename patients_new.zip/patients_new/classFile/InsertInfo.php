<?php
Class InsertInfo{
    public __construct(){}
    
    public function test($id){
        return $id;
    }
}
?>