<?php
include("./config/config.php");

class MyClass{
	public function __construct(){}
	
	public function getDiseases(){
		$qry = mysql_query("SELECT id,name FROM disease");
		$data = array();
		while($diseaseRow = mysql_fetch_assoc($qry)){
			$data[] = $diseaseRow;
		}
		return $data;
	}
	
	public function addPatient($data){
		
	}
}

?>