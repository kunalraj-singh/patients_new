<?php
include("./config/config.php");

class Patient{
	public function __construct(){}
	
	public function addPatient($data){
		//echo "<pre>";print_r($data);die;
		$fname = $data['fname'];
	    $lname = $data['lname'];
        $mobile = $data['mobile'];
        $email = $data['email'];
        $cemail = $data['cemail'];
        $password = $data['password'];
        $created = date('Y-m-d');
	    $disease = $data['disease'];
	    $gender = $data['gender'];
	    $age = $data['age'];
		$profile_img = $data['profile_img'];
		$md5_password = md5($password);
		
		$query = "INSERT INTO patients(profile_img,disease,fname,lname,gender,age,email,password,md5_password,mobile,registration_date) VALUES('$profile_img','$disease','$fname','$lname','$gender','$age','$email','$password','$md5_password','$mobile','$created')";
			  
		$insert = mysql_query($query);
		
		return $insert;
	}
}

?>