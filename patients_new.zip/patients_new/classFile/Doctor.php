<?php
include("./config/config.php");

class Doctor{
	public function __construct(){}
	
	public function addDoctor($data){
		//echo "<pre>";print_r($data);die;
		$fname = $data['fname'];
	    $lname = $data['lname'];
        $mobile = $data['mobile'];
        $email = $data['email'];
        $cemail = $data['cemail'];
        $password = $data['password'];
        $created = date('Y-m-d');
	    $disease = $data['disease'];
	    $gender = $data['gender'];
	    $age = $data['age'];
		$profile_img = $data['profile_img'];
		
		$query = "INSERT INTO doctors(profile_img,disease,fname,lname,email,password,mobile,created) VALUES('$profile_img','$disease','$fname','$lname','$email','$password','$mobile','$created')";
			  
		$insert = mysql_query($query);
		
		return $insert;
	}
}

?>