<?php
$con = mysql_connect('localhost', 'root', '');
if(!$con){
	die("Database not connect" . mysql_error());
}

$database = mysql_select_db("patients");

?>