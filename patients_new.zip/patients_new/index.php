
    <?php include('includes/header.php');?>
    <div class="clr"></div>
    <div class="body body_bg">
      <div class="left">
        <h3><span>Welcome to</span> Patients Like me</h3>
        <div class="body-row">
          <div class="welcome-img"><img src="images/welcome-img.jpg" width="185" height="130" /></div>
          <div class="welcome-img-details">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
          </div>
          <div class="clr"> </div>
        </div>
        <div class="body-row">
          <p>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>
        </div>
        <div class="body-row">
          <p>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>
        </div>
        <div class="body-row"><img src="images/read-more-buttan.jpg" width="90" height="26" style="float:right;" />
          <div class="clr"> </div>
        </div>
        <h2>Your experience <span>matters.</span></h2>
        <div class="body-row">
          <p>At PatientsLikeMe, you'll find the resources and support you need to improve your own health. Ask questions, get answers, and help make healthcare better for everyone.</p>
        </div>
        <div class="body-row"> <img src="images/scroll-middle-img.jpg" width="719" height="257" /> </div>
      </div>
      <?php include('includes/rightside.php'); ?>
      <div class="clr"></div>
    </div>
    <?php include('includes/footer.php'); ?>
  